(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,t=`http://localhost:5174/`,n=document.getElementById(`app`),r={kind:`loading`},i;function a(e){r=e,u()}async function o(){let[n]=await e.tabs.query({active:!0,currentWindow:!0});i=n?.id,await e.action.setBadgeText({text:``});let{lastSend:r,lastExtract:o}=await e.storage.local.get([`lastSend`,`lastExtract`]);if(r&&!r.ok&&Date.now()-r.at<6e5)return await e.storage.local.remove(`lastSend`),a({kind:`error`,message:`El último envío falló: ${r.error}`,data:o});a(n?.url?.startsWith(t)?{kind:`ready`}:{kind:`not-portal`})}async function s(){if(i!=null){a({kind:`extracting`});try{let t=await e.tabs.sendMessage(i,{type:`MM_EXTRACT`});if(!t.ok)return a({kind:`error`,message:t.error});await e.storage.local.set({lastExtract:t.data}),a({kind:`extracted`,data:t.data})}catch{a({kind:`error`,message:`No se pudo leer la página. Recarga el portal (F5) e inténtalo de nuevo.`})}}}async function c(t){a({kind:`sending`,data:t});let n=await e.runtime.sendMessage({type:`MM_SEND`,payload:t});n?.ok?a({kind:`sent`,data:t}):a({kind:`error`,message:n?.error??`No se pudo enviar.`,data:t})}function l(e){let t=e.offer,n=t.sections.filter(e=>e.professorName).length,r=t.sections.filter(e=>e.shift===`NOCHE`).length;return`
    <div class="card">
      <div><b>${f(t.term)}</b> · <small>${f(t.student.name)} (${f(t.student.code)})</small></div>
      <div class="grid">
        <div><b>${t.courses.length}</b><span>cursos</span></div>
        <div><b>${t.sections.length}</b><span>secciones</span></div>
        <div><b>${t.professors.length}</b><span>docentes</span></div>
        <div><b>${Math.round(n/Math.max(1,t.sections.length)*100)}%</b><span>secciones con docente</span></div>
        <div><b>${t.sections.length-r}</b><span>en la mañana</span></div>
        <div><b>${r}</b><span>en la noche</span></div>
      </div>
    </div>`}function u(){let i=r;switch(i.kind){case`loading`:n.innerHTML=`<p>Cargando…</p>`;break;case`not-portal`:n.innerHTML=`
        <div class="status"><span class="dot warn"></span>No estás en el portal de matrícula</div>
        <p>Abre el portal, inicia sesión y vuelve a presionar este botón.</p>
        <button id="open">Abrir portal de matrícula</button>`,d(`open`,()=>e.tabs.create({url:t}));break;case`ready`:n.innerHTML=`
        <div class="status"><span class="dot ok"></span>Portal de matrícula detectado</div>
        <p>Leeremos los cursos, secciones, horarios, turnos y docentes que ofrece el portal.</p>
        <button id="extract">Extraer oferta</button>`,d(`extract`,s);break;case`extracting`:n.innerHTML=`<p>Leyendo la oferta del portal…</p><button disabled>Extrayendo…</button>`;break;case`extracted`:n.innerHTML=`
        <div class="status"><span class="dot ok"></span>Oferta lista para enviar</div>
        ${l(i.data)}
        <button id="send">Enviar a MiMatrícula</button>
        <button id="again" class="secondary">Volver a extraer</button>`,d(`send`,()=>c(i.data)),d(`again`,s);break;case`sending`:n.innerHTML=`${l(i.data)}<button disabled>Enviando a MiMatrícula…</button>`;break;case`sent`:n.innerHTML=`
        <div class="success">Listo. MiMatrícula recibió ${i.data.offer.courses.length} cursos y ${i.data.offer.sections.length} secciones.</div>
        ${l(i.data)}`;break;case`error`:n.innerHTML=`
        <div class="error">${f(i.message)}</div>
        ${i.data?`<button id="retry">Reintentar envío</button>`:`<button id="again">Reintentar</button>`}`,i.data?d(`retry`,()=>c(i.data)):d(`again`,s)}}function d(e,t){document.getElementById(e)?.addEventListener(`click`,()=>void t())}function f(e){return e.replace(/[&<>"']/g,e=>({"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`,"'":`&#39;`})[e])}o();