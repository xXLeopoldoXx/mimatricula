(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,t=e=>e.endsWith(`/`)?e:`${e}/`;t(`https://mimatricula.vercel.app/`);var n=t(`https://mimatricula-portal.vercel.app/`),r=document.getElementById(`app`),i={kind:`loading`},a;function o(e){i=e,d()}async function s(){let[t]=await e.tabs.query({active:!0,currentWindow:!0});a=t?.id,await e.action.setBadgeText({text:``});let{lastSend:r,lastExtract:i}=await e.storage.local.get([`lastSend`,`lastExtract`]);if(r&&!r.ok&&Date.now()-r.at<6e5)return await e.storage.local.remove(`lastSend`),o({kind:`error`,message:`El último envío falló: ${r.error}`,data:i});o(t?.url?.startsWith(n)?{kind:`ready`}:{kind:`not-portal`})}async function c(){if(a!=null){o({kind:`extracting`});try{let t=await e.tabs.sendMessage(a,{type:`MM_EXTRACT`});if(!t.ok)return o({kind:`error`,message:t.error});await e.storage.local.set({lastExtract:t.data}),o({kind:`extracted`,data:t.data})}catch{o({kind:`error`,message:`No se pudo leer la página. Recarga el portal (F5) e inténtalo de nuevo.`})}}}async function l(t){o({kind:`sending`,data:t});let n=await e.runtime.sendMessage({type:`MM_SEND`,payload:t});n?.ok?o({kind:`sent`,data:t}):o({kind:`error`,message:n?.error??`No se pudo enviar.`,data:t})}function u(e){let t=e.offer,n=t.sections.filter(e=>e.professorName).length,r=t.sections.filter(e=>e.shift===`NOCHE`).length;return`
    <div class="card">
      <div><b>${p(t.term)}</b> · <small>${p(t.student.name)} (${p(t.student.code)})</small></div>
      <div class="grid">
        <div><b>${t.courses.length}</b><span>cursos</span></div>
        <div><b>${t.sections.length}</b><span>secciones</span></div>
        <div><b>${t.professors.length}</b><span>docentes</span></div>
        <div><b>${Math.round(n/Math.max(1,t.sections.length)*100)}%</b><span>secciones con docente</span></div>
        <div><b>${t.sections.length-r}</b><span>en la mañana</span></div>
        <div><b>${r}</b><span>en la noche</span></div>
      </div>
    </div>`}function d(){let t=i;switch(t.kind){case`loading`:r.innerHTML=`<p>Cargando…</p>`;break;case`not-portal`:r.innerHTML=`
        <div class="status"><span class="dot warn"></span>No estás en el portal de matrícula</div>
        <p>Abre el portal, inicia sesión y vuelve a presionar este botón.</p>
        <button id="open">Abrir portal de matrícula</button>`,f(`open`,()=>e.tabs.create({url:n}));break;case`ready`:r.innerHTML=`
        <div class="status"><span class="dot ok"></span>Portal de matrícula detectado</div>
        <p>Leeremos los cursos, secciones, horarios, turnos y docentes que ofrece el portal.</p>
        <button id="extract">Extraer oferta</button>`,f(`extract`,c);break;case`extracting`:r.innerHTML=`<p>Leyendo la oferta del portal…</p><button disabled>Extrayendo…</button>`;break;case`extracted`:r.innerHTML=`
        <div class="status"><span class="dot ok"></span>Oferta lista para enviar</div>
        ${u(t.data)}
        <button id="send">Enviar a MiMatrícula</button>
        <button id="again" class="secondary">Volver a extraer</button>`,f(`send`,()=>l(t.data)),f(`again`,c);break;case`sending`:r.innerHTML=`${u(t.data)}<button disabled>Enviando a MiMatrícula…</button>`;break;case`sent`:r.innerHTML=`
        <div class="success">Listo. MiMatrícula recibió ${t.data.offer.courses.length} cursos y ${t.data.offer.sections.length} secciones.</div>
        ${u(t.data)}`;break;case`error`:r.innerHTML=`
        <div class="error">${p(t.message)}</div>
        ${t.data?`<button id="retry">Reintentar envío</button>`:`<button id="again">Reintentar</button>`}`,t.data?f(`retry`,()=>l(t.data)):f(`again`,c)}}function f(e,t){document.getElementById(e)?.addEventListener(`click`,()=>void t())}function p(e){return e.replace(/[&<>"']/g,e=>({"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`,"'":`&#39;`})[e])}s();